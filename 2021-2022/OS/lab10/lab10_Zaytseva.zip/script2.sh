#!/bin/bash

echo "Args"
for a in $@   #цикл для прохода по введнным аргументам
do echo $a    #вывод аргумента
done
